# TCFI crash unwinder

`cfi_unwind` reads one crash record and one compact call-frame table, then writes a JSON stack report. The command is:

```
/app/task_file/build/cfi_unwind <crash-record> <report-json>
```

The crash record is UTF-8 text. Blank lines are ignored. `CFI <path>` gives the table file. `BASE <hex>` gives the data-relative base used by encoded addresses. Each thread starts with `THREAD <id>`, followed by `START <hex>`, zero or more `REG <number> <hex>` and `MEM <address> <hex64>` lines, and an `END` line. Thread ids are emitted in record order. Register numbers and addresses are unsigned integers; `MEM` stores one little-endian machine word at the exact address.

The table file starts with `TCFI`, version byte `1`, little-endian `u16` CIE count, and little-endian `u16` FDE count. Each CIE is `u32 id`, ULEB code alignment, SLEB data alignment, ULEB return-address register, ULEB augmentation length, augmentation bytes, little-endian `u16` instruction length, then that many instruction bytes. Each FDE is `u32 cie_id`, one pointer-encoding byte, an encoded initial location, an encoded address range, little-endian `u16` instruction length, then instruction bytes. Supported pointer formats are absolute pointer, ULEB, SLEB, udata2, udata4, udata8, sdata4, and sdata8. `pcrel` values are relative to the start offset of the encoded field. `datarel` values are relative to `BASE`.

The instruction stream uses this DWARF CFI subset: `advance_loc` primary opcodes, `offset` primary opcodes, `restore` primary opcodes, `DW_CFA_nop`, `DW_CFA_advance_loc1`, `DW_CFA_advance_loc2`, `DW_CFA_def_cfa`, `DW_CFA_def_cfa_register`, `DW_CFA_def_cfa_offset`, `DW_CFA_def_cfa_offset_sf`, `DW_CFA_same_value`, `DW_CFA_register`, `DW_CFA_remember_state`, `DW_CFA_restore_state`, `DW_CFA_offset_extended`, `DW_CFA_offset_extended_sf`, `DW_CFA_val_offset`, and `DW_CFA_val_offset_sf`. Factored offsets use the CIE data alignment. Location advances use the CIE code alignment. CIE instructions form the initial row for all FDEs that reference that CIE. An FDE applies to `initial_location <= pc < initial_location + address_range`.

For the first frame of a thread, use `START` as the lookup PC. For later frames, the emitted PC is the recovered return address and the FDE lookup PC is one byte before it. The CFA is `register + offset`. Return-address rules can read a word at `CFA + offset`, copy another register, preserve the same register value, or produce a value offset from the CFA. After a non-zero return address is recovered, the next frame uses the same register set with the CFA register set to the computed CFA and the return-address register set to the recovered PC. Stop unwinding when the return address is zero, no matching FDE exists, a required register or memory word is absent, a cycle is detected, or 32 frames have been emitted.

The JSON output must have this shape and stable key order:

```
{
  "input": "<crash-record path>",
  "threads": [
    {
      "id": "<thread id>",
      "frames": [
        {"index": 0, "pc": "0x...", "cfa": "0x...", "return_address": "0x...", "status": "ok"}
      ]
    }
  ],
  "summary": {"thread_count": 1, "complete_threads": 1, "frame_count": 1}
}
```

Use lowercase hexadecimal without leading zero padding except for zero itself. If a frame cannot produce a return address, use `null` for `return_address` and put the stop reason in `status`; otherwise use `ok`. A thread is complete when its final frame has `root` status.
